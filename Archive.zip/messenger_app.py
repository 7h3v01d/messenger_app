"""
Standalone Facebook Messenger desktop app.

A PyQt6 + QtWebEngine wrapper around messenger.com, giving it a native
window, system tray icon, and desktop notifications.

Requirements:
    pip install PyQt6 PyQt6-WebEngine comtypes pywin32

Files:
    messenger_app.py    - this file, the main window/app
    icon_assets.py       - draws the app icon and unread badge icons
    windows_taskbar.py   - Windows taskbar overlay badge (ITaskbarList3)

Run:
    python messenger_app.py
"""

import re
import sys
from PyQt6.QtCore import QUrl, Qt, pyqtSlot, QFile, QIODevice
from PyQt6.QtGui import QIcon, QAction, QDesktopServices, QGuiApplication
from PyQt6.QtWidgets import QApplication, QMainWindow, QSystemTrayIcon, QMenu
from PyQt6.QtWebEngineCore import (
    QWebEngineProfile,
    QWebEnginePage,
    QWebEngineSettings,
    QWebEngineScript,
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import QObject

from icon_assets import build_app_icon
from windows_taskbar import TaskbarBadge
from startup_manager import is_startup_enabled, set_startup_enabled
from global_hotkey import GlobalHotkey, MOD_CONTROL, MOD_ALT

# Matches Messenger's title prefix, e.g. "(3) Messenger"
UNREAD_TITLE_RE = re.compile(r"^\((\d+)\)")

MESSENGER_URL = "https://messenger.com"

# A normal desktop Chrome UA so Facebook serves the full web app.
DESKTOP_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# Injected as a QWebEngineScript at document-creation time (before any
# page script runs), so `qt.webChannelTransport` is already available
# by the time this executes. Overrides window.Notification so any
# notification Messenger's web app tries to show is instead forwarded
# to Qt via the QWebChannel bridge, letting us raise a native OS
# notification from the tray icon instead of a browser-style popup.
NOTIFICATION_BRIDGE_JS = """
(function() {
    if (!window.qt) return;
    new QWebChannel(qt.webChannelTransport, function(channel) {
        window.pyBridge = channel.objects.pyBridge;

        const OriginalNotification = window.Notification;
        function PatchedNotification(title, options) {
            options = options || {};
            if (window.pyBridge) {
                window.pyBridge.notify(title, options.body || "");
            }
            // Still construct a real (silent/no-op) Notification object
            // so page scripts that inspect it don't break, but we don't
            // rely on the browser rendering it.
            return new OriginalNotification(title, options);
        }
        PatchedNotification.permission = "granted";
        PatchedNotification.requestPermission = function(cb) {
            if (cb) cb("granted");
            return Promise.resolve("granted");
        };
        window.Notification = PatchedNotification;
    });
})();
"""


def _load_qwebchannel_js() -> str:
    """Reads Qt's bundled qwebchannel.js out of its Qt resource file."""
    f = QFile(":/qtwebchannel/qwebchannel.js")
    if not f.open(QIODevice.OpenModeFlag.ReadOnly):
        raise RuntimeError(
            "Could not load qwebchannel.js from Qt resources — "
            "check your PyQt6-WebEngine install."
        )
    try:
        return bytes(f.readAll()).decode("utf-8")
    finally:
        f.close()


def build_notification_bridge_script() -> QWebEngineScript:
    """A QWebEngineScript combining qwebchannel.js + our bridge JS,
    injected before the page's own scripts run on every navigation."""
    script = QWebEngineScript()
    script.setName("messenger-notification-bridge")
    script.setSourceCode(_load_qwebchannel_js() + "\n" + NOTIFICATION_BRIDGE_JS)
    script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
    script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
    script.setRunsOnSubFrames(False)
    return script


class Bridge(QObject):
    """Exposed to the page via QWebChannel; receives notification calls."""

    def __init__(self, on_notify):
        super().__init__()
        self._on_notify = on_notify

    @pyqtSlot(str, str)
    def notify(self, title: str, body: str):
        self._on_notify(title, body)


class MessengerPage(QWebEnginePage):
    """Plain QWebEnginePage — the notification bridge is injected via a
    QWebEngineScript on the profile instead of manual DOM injection."""
    pass


class MessengerView(QWebEngineView):
    """QWebEngineView with a trimmed, chat-app-appropriate context menu
    instead of Chromium's full default (which includes irrelevant items
    like View Page Source, Save As, and Print)."""

    # Keeps "Inspect Element" available for debugging. Set False before
    # handing this off to a non-technical user.
    DEV_MODE = True

    def contextMenuEvent(self, event):
        request = self.lastContextMenuRequest()
        menu = QMenu(self)
        page = self.page()

        misspelled = request.misspelledWord()
        if misspelled:
            suggestions = request.spellCheckerSuggestions()
            if suggestions:
                for suggestion in suggestions[:5]:
                    action = menu.addAction(suggestion)
                    action.triggered.connect(
                        lambda checked=False, s=suggestion: page.replaceMisspelledWord(s)
                    )
            else:
                none_action = menu.addAction(f'No suggestions for "{misspelled}"')
                none_action.setEnabled(False)
            menu.addSeparator()

        editable = request.isContentEditable()
        has_selection = bool(request.selectedText())

        if editable:
            undo_action = menu.addAction("Undo")
            undo_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.Undo)
            )
            redo_action = menu.addAction("Redo")
            redo_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.Redo)
            )
            menu.addSeparator()

            cut_action = menu.addAction("Cut")
            cut_action.setEnabled(has_selection)
            cut_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.Cut)
            )

        copy_action = menu.addAction("Copy")
        copy_action.setEnabled(has_selection)
        copy_action.triggered.connect(
            lambda: page.triggerAction(QWebEnginePage.WebAction.Copy)
        )

        if editable:
            paste_action = menu.addAction("Paste")
            paste_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.Paste)
            )

        select_all_action = menu.addAction("Select All")
        select_all_action.triggered.connect(
            lambda: page.triggerAction(QWebEnginePage.WebAction.SelectAll)
        )

        link_url = request.linkUrl()
        if not link_url.isEmpty():
            menu.addSeparator()
            copy_link_action = menu.addAction("Copy Link")
            copy_link_action.triggered.connect(
                lambda: QGuiApplication.clipboard().setText(link_url.toString())
            )
            open_link_action = menu.addAction("Open Link in Browser")
            open_link_action.triggered.connect(lambda: QDesktopServices.openUrl(link_url))

        media_url = request.mediaUrl()
        if not media_url.isEmpty():
            menu.addSeparator()
            copy_image_action = menu.addAction("Copy Image")
            copy_image_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.CopyImageToClipboard)
            )

        menu.addSeparator()
        reload_action = menu.addAction("Reload")
        reload_action.triggered.connect(
            lambda: page.triggerAction(QWebEnginePage.WebAction.Reload)
        )

        if self.DEV_MODE:
            menu.addSeparator()
            inspect_action = menu.addAction("Inspect Element")
            inspect_action.triggered.connect(
                lambda: page.triggerAction(QWebEnginePage.WebAction.InspectElement)
            )

        menu.popup(event.globalPos())


class MessengerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Messenger")
        self.resize(1100, 750)

        self.app_icon = build_app_icon()
        self.setWindowIcon(self.app_icon)
        self.taskbar_badge = None  # created after the native window exists

        # Persistent profile so login/session survives restarts.
        profile = QWebEngineProfile("messenger-standalone", self)
        profile.setHttpUserAgent(DESKTOP_USER_AGENT)
        profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True
        )
        profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.ScreenCaptureEnabled, True
        )
        profile.setSpellCheckEnabled(True)
        # Adjust to match your locale/keyboard if needed, e.g. "en-GB".
        profile.setSpellCheckLanguages(["en-US"])
        profile.scripts().insert(build_notification_bridge_script())

        self.view = MessengerView(self)
        self.page = MessengerPage(profile, self.view)
        self.view.setPage(self.page)

        # Web channel + bridge object for JS -> Python notification calls.
        self.channel = QWebChannel(self.page)
        self.bridge = Bridge(self._show_notification)
        self.channel.registerObject("pyBridge", self.bridge)
        self.page.setWebChannel(self.channel)

        self.setCentralWidget(self.view)
        self.view.load(QUrl(MESSENGER_URL))
        self.view.titleChanged.connect(self._on_title_changed)

        self._build_tray_icon()
        self._setup_global_hotkey()

    def _setup_global_hotkey(self):
        # Ctrl+Alt+M to show/hide from anywhere. Change the modifiers/
        # key here if it clashes with something else on your system.
        self.hotkey = GlobalHotkey(modifiers=MOD_CONTROL | MOD_ALT, key="M")
        self.hotkey.activated.connect(self._toggle_visibility)
        QApplication.instance().installNativeEventFilter(self.hotkey)
        QApplication.instance().aboutToQuit.connect(self.hotkey.unregister)

    def _toggle_visibility(self):
        if self.isVisible() and self.isActiveWindow():
            self.hide()
        else:
            self._restore_from_tray()

    def _build_tray_icon(self):
        self.tray = QSystemTrayIcon(self)
        self.tray.setIcon(self.app_icon)
        self.tray.setToolTip("Messenger")

        menu = QMenu()
        show_action = QAction("Show Messenger", self)
        show_action.triggered.connect(self._restore_from_tray)

        startup_action = QAction("Launch at Startup", self)
        startup_action.setCheckable(True)
        startup_action.setChecked(is_startup_enabled())
        startup_action.toggled.connect(set_startup_enabled)

        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(QApplication.instance().quit)

        menu.addAction(show_action)
        menu.addSeparator()
        menu.addAction(startup_action)
        menu.addSeparator()
        menu.addAction(quit_action)

        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self._restore_from_tray()

    def _restore_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _on_title_changed(self, title: str):
        # Messenger sometimes prefixes the page title with an unread
        # count, e.g. "(3) Messenger". Surface that on the window title,
        # the taskbar overlay badge, and the tray tooltip.
        self.setWindowTitle(title or "Messenger")

        match = UNREAD_TITLE_RE.match(title or "")
        count = int(match.group(1)) if match else 0

        if self.taskbar_badge is not None:
            self.taskbar_badge.set_count(count)

        self.tray.setToolTip(f"Messenger ({count} unread)" if count else "Messenger")

    def showEvent(self, event):
        super().showEvent(event)
        # winId() only resolves to a real native handle once the window
        # has been shown, so the taskbar badge is created here rather
        # than in __init__.
        if self.taskbar_badge is None:
            self.taskbar_badge = TaskbarBadge(int(self.winId()))

    def _show_notification(self, title: str, body: str):
        self.tray.showMessage(
            title or "Messenger",
            body,
            QSystemTrayIcon.MessageIcon.Information,
            5000,
        )

    def closeEvent(self, event):
        # Minimize to tray instead of quitting, like a real chat app.
        event.ignore()
        self.hide()
        self.tray.showMessage(
            "Messenger",
            "Still running in the tray.",
            QSystemTrayIcon.MessageIcon.Information,
            2000,
        )


def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName("Messenger")

    window = MessengerWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
