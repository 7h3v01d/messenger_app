# Messenger (standalone desktop app)

A standalone desktop client for Facebook Messenger, built to replace
the official app Facebook discontinued. It's a native window wrapped
around the real `messenger.com` web app (via PyQt6 + QtWebEngine),
not a reverse-engineered API client — so it stays in sync with
whatever Facebook changes on their end, with no ToS-risky login
spoofing.

## Features

- Native window, system tray icon, and app icon (drawn at runtime —
  no external image asset needed)
- Desktop notifications: Messenger's own in-page notifications are
  intercepted and re-shown as native OS tray notifications
- Minimizes to tray on close instead of quitting
- Windows taskbar overlay badge showing the unread count
- Trimmed right-click context menu (spellcheck, cut/copy/paste,
  link/image actions) instead of Chromium's full default menu
- "Launch at Startup" toggle in the tray menu
- Global hotkey (default **Ctrl+Alt+M**) to show/hide from anywhere

## Requirements

- Python 3.10+
- Windows for the full feature set (taskbar badge, startup toggle,
  global hotkey). Runs on macOS/Linux for development — those three
  features just no-op there and the rest works normally.

## Installation

```
pip install -r requirements.txt
```

## Usage

```
python messenger_app.py
```

First run opens the normal Messenger login page inside the app
window; your session persists between launches (stored in a local
QtWebEngine profile named `messenger-standalone`), so you only log
in once.

## Files

| File | Purpose |
|---|---|
| `messenger_app.py` | Main window, tray icon, notification bridge, context menu |
| `icon_assets.py` | Draws the app icon and unread-count badge icons |
| `windows_taskbar.py` | Windows taskbar overlay badge (`ITaskbarList3` via `comtypes`) |
| `startup_manager.py` | Launch-at-startup toggle (`HKCU\...\Run` registry key) |
| `global_hotkey.py` | System-wide show/hide hotkey (`RegisterHotKey` via `ctypes`) |

## Customization

- **Hotkey**: change the modifiers/key in
  `MessengerWindow._setup_global_hotkey()` in `messenger_app.py` if
  Ctrl+Alt+M clashes with something else on your system.
- **Spellcheck language**: set in `MessengerWindow.__init__` via
  `profile.setSpellCheckLanguages([...])` — defaults to `en-US`.
- **Developer tools**: `MessengerView.DEV_MODE = True` keeps
  "Inspect Element" in the right-click menu. Set to `False` if this
  is ever handed off to a non-technical user.
- **App icon**: currently a drawn placeholder (blue rounded square,
  "M" mark). Replace the body of `build_app_icon()` in
  `icon_assets.py` with a real designed icon whenever you have one.

## Known limitations

- The startup toggle registers the *current* Python interpreter and
  script path in the registry. If this is later packaged as a
  standalone `.exe` (e.g. via PyInstaller), `startup_manager.py`'s
  `_launch_command()` will need updating to point at that instead —
  otherwise a moved/renamed dev folder will silently break the
  startup entry.
- Voice/video calls rely on QtWebEngine's Chromium build supporting
  whatever WebRTC features Messenger currently needs; not
  exhaustively tested end-to-end.
- Console warnings about `Permissions-Policy` headers and `unload`
  listeners in the terminal are harmless — they come from Facebook's
  own page code hitting minor gaps in QtWebEngine's bundled Chromium
  version, not from this app.
